# selmerBot

Authors: ION606, MajorDrools

Description:
This is a bot modeled after Selmer Bringsjord of RPI and all the wonderful things he says
